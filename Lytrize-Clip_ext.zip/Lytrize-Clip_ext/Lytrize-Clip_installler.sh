#!/bin/bash
# Lytrize-Clip Installer
# Installs the unpacked extension by modifying browser Preferences.
# Compatible with Manifest V2 and V3 extensions.

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
EXT_PATH="$SCRIPT_DIR/Lytrize-Clip"
BROWSER="${1:-auto}"
PROFILE="${2:-Default}"

if [ ! -f "$EXT_PATH/manifest.json" ]; then
    echo -e "${RED}Error: Lytrize-Clip/ folder not found next to this script.${NC}"
    echo "Expected: $EXT_PATH"
    exit 1
fi

# Generate or use existing extension key
# For Manifest V3, Chrome requires a persistent key to identify the extension
generate_extension_key() {
    local ext_path="$1"
    local key_file="$ext_path/.lytrize_key.pem"
    local pub_key_b64
    local ext_id
    
    if [ ! -f "$key_file" ]; then
        echo -e "${YELLOW}Generating extension key...${NC}" >&2
        # Generate RSA key pair for extension identification
        openssl genrsa -out "$key_file" 2048 2>/dev/null
        echo -e "${GREEN}Key generated: $key_file${NC}" >&2
    else
        echo -e "${GREEN}Using existing key: $key_file${NC}" >&2
    fi
    
    # Extract public key in base64 format for manifest
    pub_key_b64=$(openssl rsa -in "$key_file" -pubout -outform PEM 2>/dev/null | \
        grep -v '^-----' | tr -d '\n')
    
    # Calculate extension ID from public key (Chrome's algorithm)
    ext_id=$(openssl rsa -in "$key_file" -pubout -outform DER 2>/dev/null | \
        python3 -c "import sys, hashlib; d=sys.stdin.buffer.read(); h=hashlib.sha256(d).digest()[:16]; print(''.join(chr(ord('a')+(b>>4))+chr(ord('a')+(b&0x0F)) for b in h))")
    
    # Update manifest.json with the public key for Manifest V3
    local manifest_file="$ext_path/manifest.json"
    local temp_manifest="$ext_path/manifest.json.tmp"
    
    python3 -c "
import json, sys

manifest_path = sys.argv[1]
pub_key = sys.argv[2]
temp_path = sys.argv[3]

with open(manifest_path, 'r') as f:
    manifest = json.load(f)

# Add the key to manifest for Manifest V3
manifest['key'] = pub_key

with open(temp_path, 'w') as f:
    json.dump(manifest, f, indent=2)
    f.write('\n')
" "$manifest_file" "$pub_key_b64" "$temp_manifest"
    
    mv "$temp_manifest" "$manifest_file"
    echo -e "${GREEN}Updated manifest.json with extension key${NC}" >&2
    
    # Only output the extension ID to stdout
    echo "$ext_id"
}

EXT_ID=$(generate_extension_key "$EXT_PATH")
echo -e "${BLUE}Extension ID:${NC} $EXT_ID"

# Detect browser profile directory
detect_profile() {
    local name="$1"
    local paths=()
    case "$name" in
        chrome)
            paths=("$HOME/.config/google-chrome/$PROFILE" "$HOME/.config/google-chrome")
            ;;
        chromium)
            paths=("$HOME/.config/chromium/$PROFILE" "$HOME/.config/chromium")
            ;;
        edge)
            paths=("$HOME/.config/microsoft-edge/$PROFILE" "$HOME/.config/microsoft-edge")
            ;;
        brave)
            paths=("$HOME/.config/BraveSoftware/Brave-Browser/$PROFILE" "$HOME/.config/BraveSoftware/Brave-Browser")
            ;;
        opera)
            paths=("$HOME/.config/opera")
            ;;
        vivaldi)
            paths=("$HOME/.config/vivaldi/$PROFILE" "$HOME/.config/vivaldi")
            ;;
    esac
    for p in "${paths[@]}"; do
        if [ -d "$p" ]; then
            PROFILE_DIR="$p"
            DETECTED_BROWSER="$name"
            return 0
        fi
    done
    return 1
}

SELECTED_BROWSER=""
if [ "$BROWSER" = "auto" ]; then
    for b in chrome chromium edge brave opera vivaldi; do
        if detect_profile "$b"; then
            SELECTED_BROWSER="$DETECTED_BROWSER"
            break
        fi
    done
else
    if detect_profile "$BROWSER"; then
        SELECTED_BROWSER="$DETECTED_BROWSER"
    fi
fi

if [ -z "$SELECTED_BROWSER" ]; then
    echo -e "${RED}Error: Could not find browser profile directory.${NC}"
    echo "Supported browsers: chrome, chromium, edge, brave, opera, vivaldi"
    echo "Usage: $0 [browser] [profile]"
    echo "Example: $0 chrome Default"
    exit 1
fi

PREFS="$PROFILE_DIR/Preferences"
SECURE_PREFS="$PROFILE_DIR/Secure Preferences"

# Create Preferences file if it doesn't exist (first-time browser run)
if [ ! -f "$PREFS" ]; then
    echo -e "${YELLOW}Preferences file not found. Creating new one...${NC}"
    echo -e "${BLUE}This appears to be the first time running $SELECTED_BROWSER.${NC}"
    echo '{}' > "$PREFS"
    echo -e "${GREEN}Created: $PREFS${NC}"
fi

if [ -f "$SECURE_PREFS" ]; then
    echo -e "${BLUE}Secure Preferences:${NC} Found (will update both files)"
fi

echo -e "${BLUE}Browser:${NC}          $SELECTED_BROWSER"
echo -e "${BLUE}Profile:${NC}          $PROFILE_DIR"
echo -e "${BLUE}Extension folder:${NC} $EXT_PATH"
echo -e "${BLUE}Extension ID:${NC}     $EXT_ID"
echo ""

# Check if browser is running
BROWSER_PIDS=""
for proc in chrome chromium brave msedge opera vivaldi; do
    PIDS=$(pgrep -x "$proc" 2>/dev/null || true)
    if [ -n "$PIDS" ]; then
        BROWSER_PIDS="$BROWSER_PIDS $PIDS"
    fi
done

if [ -n "$BROWSER_PIDS" ]; then
    echo -e "${YELLOW}WARNING: A Chromium-based browser is running.${NC}"
    echo -e "${YELLOW}Close it first, or changes may be lost.${NC}"
    echo ""
    read -p "Press Enter to continue, or Ctrl+C to cancel..."
fi

# Backup
BACKUP="$PREFS.lytrize-backup-$(date +%s)"
cp "$PREFS" "$BACKUP"
echo -e "${GREEN}Backup created:${NC} $BACKUP"

# Update Preferences file using Python for Manifest V3 compatibility
python3 - "$EXT_PATH" "$PREFS" "$EXT_ID" << 'PYTHON_EOF'
import sys, json, os, time

ext_path = sys.argv[1]
prefs_path = sys.argv[2]
ext_id = sys.argv[3]

# Read current preferences
with open(prefs_path, "r") as f:
    prefs = json.load(f)

# Ensure extensions structure exists
prefs.setdefault("extensions", {})
prefs["extensions"].setdefault("settings", {})
prefs["extensions"].setdefault("ui", {})

# Enable developer mode
prefs["extensions"]["ui"]["developer_mode"] = True

# Get absolute path
abs_ext_path = os.path.realpath(ext_path)

# For Manifest V3, Chrome requires specific fields
# The critical part is that the path must be absolute and the extension
# must pass validation when the browser starts
prefs["extensions"]["settings"][ext_id] = {
    "path": abs_ext_path,
    "location": 4,  # 4 = unpacked extension (developer loaded)
    "state": 1,     # 1 = enabled
    "install_time": str(int(time.time() * 1000000)),
    "was_installed_by_default": False,
    "was_installed_by_oem": False,
    "acknowledged": True,
    "from_webstore": False,
    "creation_params": {
        "manifest": {
            "key": ext_id  # Include the extension key
        }
    }
}

# Write back with proper formatting (preserve existing structure)
with open(prefs_path, "w") as f:
    json.dump(prefs, f, separators=(",", ":"))

print(f"Extension registered with ID: {ext_id}")
print(f"Path: {abs_ext_path}")
PYTHON_EOF

# Try to update both Preferences files
UPDATE_SCRIPT='
import sys, json, os, time

ext_path = sys.argv[1]
prefs_path = sys.argv[2]
ext_id = sys.argv[3]

try:
    # Read current preferences
    with open(prefs_path, "r") as f:
        prefs = json.load(f)
    
    # Ensure extensions structure exists
    prefs.setdefault("extensions", {})
    prefs["extensions"].setdefault("settings", {})
    prefs["extensions"].setdefault("ui", {})
    
    # Enable developer mode
    prefs["extensions"]["ui"]["developer_mode"] = True
    
    # Get absolute path
    abs_ext_path = os.path.realpath(ext_path)
    
    # Register extension
    prefs["extensions"]["settings"][ext_id] = {
        "path": abs_ext_path,
        "location": 4,
        "state": 1,
        "install_time": str(int(time.time() * 1000000)),
        "was_installed_by_default": False,
        "was_installed_by_oem": False,
        "acknowledged": True,
        "from_webstore": False,
        "creation_params": {
            "manifest": {
                "key": ext_id
            }
        }
    }
    
    # Write back
    with open(prefs_path, "w") as f:
        json.dump(prefs, f, separators=(",", ":"))
    
    print(f"Updated: {prefs_path}")
except Exception as e:
    print(f"Warning: Could not update {prefs_path}: {e}", file=sys.stderr)
'

python3 -c "$UPDATE_SCRIPT" "$EXT_PATH" "$PREFS" "$EXT_ID"

if [ -f "$SECURE_PREFS" ]; then
    python3 -c "$UPDATE_SCRIPT" "$EXT_PATH" "$SECURE_PREFS" "$EXT_ID"
fi

echo ""
echo -e "${GREEN}✓ Lytrize-Clip configuration updated.${NC}"
echo ""
echo -e "${YELLOW}IMPORTANT: Manifest V3 Security Restriction${NC}"
echo "Modern Chromium browsers (Chrome 88+, Edge 88+) no longer allow"
echo "automatic installation of unpacked extensions for security reasons."
echo ""
echo -e "${BLUE}Manual Installation Required:${NC}"
echo "1. Close all $SELECTED_BROWSER windows completely"
echo "2. Start $SELECTED_BROWSER"
echo "3. Go to: chrome://extensions/"
echo "4. Enable 'Developer mode' (toggle in top-right corner)"
echo "5. Click 'Load unpacked' button"
echo "6. Select this folder:"
echo "   $EXT_PATH"
echo ""
echo -e "${GREEN}The extension key has been generated and added to manifest.json${NC}"
echo -e "${GREEN}This ensures the extension ID remains consistent.${NC}"
echo ""
echo "Restore backup if needed:"
echo "  cp $BACKUP $PREFS"
